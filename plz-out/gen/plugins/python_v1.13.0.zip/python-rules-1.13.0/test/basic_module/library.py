
def foo():
    return "something"